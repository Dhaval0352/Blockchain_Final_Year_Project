const fs = require("fs");
const path = require("path");
const express = require("express");
const cors = require("cors");
const { ethers } = require("ethers");

const PORT = process.env.PORT || 4000;
const RPC_URL = process.env.RPC_URL || "http://127.0.0.1:8545";
const DEPLOYMENT_PATH = path.join(__dirname, "..", "deployments.json");

function loadDeployment() {
  if (!fs.existsSync(DEPLOYMENT_PATH)) {
    throw new Error(
      `deployments.json not found at ${DEPLOYMENT_PATH}. Run "npm run deploy" first.`
    );
  }
  return JSON.parse(fs.readFileSync(DEPLOYMENT_PATH, "utf8"));
}

// Ganache (unlike Hardhat's own network) doesn't populate ethers' usual
// err.reason on a revert — the human-readable message shows up nested in
// err.info.error.message instead, prefixed with "revert ". This pulls it
// out so the app gets "ChainShield: product already registered" instead
// of a huge dump of raw call data.
function extractRevertReason(err) {
  const nested = err?.info?.error?.message;
  if (typeof nested === "string") {
    const marker = "revert ";
    const idx = nested.indexOf(marker);
    if (idx !== -1) return nested.slice(idx + marker.length);
    return nested;
  }
  return err.reason || err.shortMessage || String(err);
}

// Turns any human-readable product id (e.g. "p_1737..._ab12cd") into a
// stable bytes32 value the contract can use as a mapping key. Doing this
// with keccak256 means both the app and this server always derive the
// exact same on-chain id from the same string id, without having to store
// a separate mapping anywhere.
function toBytes32Id(idString) {
  return ethers.keccak256(ethers.toUtf8Bytes(idString));
}

async function main() {
  const deployment = loadDeployment();

  const provider = new ethers.JsonRpcProvider(RPC_URL);
  // account #0 from Ganache's deterministic mnemonic — the contract owner,
  // acts on behalf of "the system" whenever the admin approves a product.
  const ownerSigner = await provider.getSigner(0);

  const contractRead = new ethers.Contract(deployment.address, deployment.abi, provider);
  const contractWrite = new ethers.Contract(deployment.address, deployment.abi, ownerSigner);

  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get("/api/chain/health", async (req, res) => {
    try {
      const network = await provider.getNetwork();
      const blockNumber = await provider.getBlockNumber();
      res.json({
        ok: true,
        contractAddress: deployment.address,
        chainId: network.chainId.toString(),
        blockNumber,
      });
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });

  // Called right after the admin approves a manufacturer's product —
  // this is the moment the record actually gets written on-chain.
  app.post("/api/chain/products", async (req, res) => {
    try {
      const {
        id, // app-level string id, e.g. "p_1737512345_ab12cd"
        productName,
        batchNumber,
        manufacturerName,
        category,
        mfgDate, // ISO date string
        expDate, // ISO date string
      } = req.body;

      if (!id || !productName) {
        return res.status(400).json({ ok: false, error: "id and productName are required" });
      }

      const productIdBytes32 = toBytes32Id(id);
      const mfgTs = mfgDate ? Math.floor(new Date(mfgDate).getTime() / 1000) : 0;
      const expTs = expDate ? Math.floor(new Date(expDate).getTime() / 1000) : 0;

      const tx = await contractWrite.addProduct(
        productIdBytes32,
        productName,
        batchNumber || "",
        manufacturerName || "",
        category || "",
        mfgTs,
        expTs
      );
      const receipt = await tx.wait();

      res.json({
        ok: true,
        txHash: receipt.hash,
        blockNumber: receipt.blockNumber,
        productIdBytes32,
      });
    } catch (err) {
      // e.g. "ChainShield: product already registered"
      res.status(400).json({ ok: false, error: extractRevertReason(err) });
    }
  });

  // Free read — used by the customer app to verify a scanned product.
  app.get("/api/chain/products/:id", async (req, res) => {
    try {
      const productIdBytes32 = toBytes32Id(req.params.id);
      const result = await contractRead.getProduct(productIdBytes32);

      if (!result[0]) {
        return res.json({ ok: true, exists: false });
      }

      res.json({
        ok: true,
        exists: true,
        productName: result[1],
        batchNumber: result[2],
        manufacturerName: result[3],
        category: result[4],
        mfgDate: result[5].toString(),
        expDate: result[6].toString(),
        onChainTimestamp: result[7].toString(),
        productIdBytes32,
      });
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });

  // Called every time a customer scans a product's QR code.
  app.post("/api/chain/products/:id/scan", async (req, res) => {
    try {
      const productIdBytes32 = toBytes32Id(req.params.id);
      const tx = await contractWrite.recordScan(productIdBytes32);
      const receipt = await tx.wait();
      const count = await contractRead.scanCount(productIdBytes32);

      res.json({ ok: true, scanCount: count.toString(), txHash: receipt.hash });
    } catch (err) {
      res.status(400).json({ ok: false, error: extractRevertReason(err) });
    }
  });

  app.listen(PORT, () => {
    console.log(`ChainShield chain-backend listening on http://localhost:${PORT}`);
    console.log(`Contract: ${deployment.address}  (network: ${deployment.network})`);
  });
}

main().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
